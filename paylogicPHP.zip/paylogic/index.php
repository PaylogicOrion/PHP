
<HTML>
<HEAD>

<script type="text/javascript" src="js/bootstrap_theme.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<link href="css/bootstrap-theme.min.css" rel="stylesheet" />
<link href="css/bootstrap.min.css" rel="stylesheet" />


<title>Payment Service Provider | Merchant Accounts</title>
<style>
.has-success .form-control, .has-success .control-label, .has-success .radio, .has-success .checkbox, .has-success .radio-inline, .has-success .checkbox-inline {
	color: #1cb78c !important;
}
.has-success .help-block {
	color: #1cb78c !important;
	border-color: #1cb78c !important;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #1cb78c;
}
.has-error .form-control, .has-error .help-block, .has-error .control-label, .has-error .radio, .has-error .checkbox, .has-error .radio-inline, .has-error .checkbox-inline {
	color: #f0334d;
	border-color: #f0334d;
	box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 6px #f0334d;
}
table {
	color: #333; /* Lighten up font color */
	font-family: "Raleway", Helvetica, Arial, sans-serif;
	font-weight: bold;
	width: 640px;
	border-collapse: collapse;
	border-spacing: 0;
}
td, th {
	border: 1px solid #CCC;
	height: 30px;
} /* Make cells a bit taller */
th {
	background: #F3F3F3; /* Light grey background */
	font-weight: bold; /* Make sure theyre bold */
	font-color: #1cb78c !important;
}
td {
	background: #FAFAFA; /* Lighter grey background */
	text-align: left;
	padding: 2px;/* Center our text */
}
label {
	font-weight: normal;
	display: block;
}
</style>
</HEAD>
<BODY>
    

<form class="form-horizontal" action="index.php" method="post"> 
  
  <div class="container cs-border-light-blue">
    <div class="row pad-top"></div>
    <div class="equalheight row" style="padding-top: 10px;">
      <div id="cs-main-body" class="cs-text-size-default pad-bottom">
        <div class="col-sm-9  equalheight-col pad-top">
          <div style="padding-bottom: 50px;">
            <h1>PAYLOGIC</h1>
            <label class="control-label col-sm-4">INTEGRATION TYPE</label>
                      <div class="col-sm-8">
                      <select class="form-control" id="integrationtype" name="integrationtype">
						<option value="" selected>Select TYPE</option>
                          <option value="http://3.108.21.243:8080/paytest/payprocessorV2">NON-Seamless</option>
                          <option value="http://3.108.21.243:8080/paytest/payprocessorV2">S2S</option>
                          <option value="">Non-Seamless-Selective-paymode</option>
                          </select>
                    </div>
</div>
                    <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">MERCHANT ID</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="merchantId" id="merchantId" value="M00005016" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">API_KEY</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="apiKey" id="apiKey" value="hr8er4hf9xW1tx1ah1qH6hU7vr7io7eR" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">RETURN_URL</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="returnURL" id="returnURL" value="http://localhost/Paylogic/response.php" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">TYPE</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="type" id="type" value="1.1" />
					 </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">ORDER_NO</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="txnId" id="txnId" value="<?php echo(rand(10000,100000000))?>" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">TXNTYPE</label>
                      <div class="col-sm-8">
                      <select class="form-control" id="txnType" name="txnType">
						<option value="" selected>Select TYPE</option>
                          <option value="DIRECT">DIRECT</option>
                          <option value="REDIRECT">REDIRECT</option> 
                          </select>
                    </div>
                    </div>
                  </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">AMOUNT</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="amount" id="amount" value="1.00" />					  
				
					  </div>
                    </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">DATETIME</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="dateTime" id="dateTime" value="<?php  echo date("Y-m-d"." "."H:i:s") ?>" />
					 </div>
                    </div>
                  </div>
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">PRODUCT_ID</label>
                      <div class="col-sm-8">
                          <input type="text" class="form-control" name="productId" id="productId" value="DEFAULT" />					  
				
					  </div>
                    </div>
                  </div>
                 

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">CHANNEL_ID</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="channelId" id="channelId" value="0" />
					 </div>
                    </div>
                  </div>
                  </div>
                          </div>
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">INSTRUMENT_ID</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="instrumentId" id="instrumentId" value="NA" />
					 </div>
                   
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">isMultiSettlement</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="isMultiSettlement" id="isMultiSettlement" value="0" />
					 </div>
                    </div>
                  </div>
                  </div>
                  </div>
              
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">CUST_MOBILE</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="custMobile" id="custMobile" value="9876543210" />
					 </div>
                   
                  </div>
                  </div>
                
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">CUST_MAIL</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="custMail" id="custMail" value="test@test.com" />
					 </div>
                    </div>
                  </div>
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">CARD_DETAILS</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="cardDetails" id="cardDetails" value="NA" />
					 </div>
                   
                  </div>
                  </div>
                
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">cardType</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="cardType" id="cardType" value="NA" />
					 </div>
                    </div>
                  </div>
                  </div>
                  </div>

                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">UDF5</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="udf5" id="udf5" value="NA" />
					 </div>
                   
                  </div>
                  </div>
                
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">UDF1</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="udf1" id="udf1" value="NA" />
					 </div>
                    </div>
                  </div>
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">UDF2</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="udf2" id="udf2" value="NA" />
					 </div>
                   
                  </div>
                  </div>
                
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">UDF3</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="udf3" id="udf3" value="NA" />
					 </div>
                    </div>
                  </div>
                  </div>
                  </div>
               
                  <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label class="control-label col-sm-4">UDF4</label>
                      <div class="col-sm-8">
					  <input type="text" class="form-control" name="udf4" id="udf4" value="NA" />
					 </div>
                   
                  </div>
                  </div>

            <div class="row">
              <div class="col-sm-12">
                <div class="form-group">
                  <div class="col-sm-10 col-sm-offset-2">
                    <button class="btn btn-primary btn-lg"
											style="display: inline-block; vertical-align: middle; vert-align: middle; float: none;" name="submit">Checkout</button>
      
  </div>
</div>
</div>
</div>
</div>
</div>



</form>
</BODY>
</HTML>

<?php 

include "function.php";


if(isset($_POST['submit'])){

$pg_request_url=$_POST['integrationtype']; ;

$post = $_POST; 

unset($post['submit']);
unset($post['integrationtype']);

$key =$post['apiKey'];

$result = json_encode($post);

$request = encrypt($result,$key);


$output = '<form id="payForm" action="'.$pg_request_url.'" method="post">';
            

            $output .= '<input type="hidden" id="reqData" name="reqData" value="' .$request. '">' . "\n";
            $output .= '<input type="hidden" id="merchantId" name="merchantId" value="M00005016">' . "\n";

            $output .= '</form><script> document.getElementById("payForm").submit(); </script><h2>Redirecting...</h2>';
            echo $output;

}






?>