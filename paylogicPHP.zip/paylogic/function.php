<?php 



function encrypt($data, $key){
    $iv = substr($key,0,16);
    
    $cipher="aes-256-cbc"; 
    
    if(strlen($iv) >0){   
    $data=openssl_encrypt($data, $cipher, $key, 0, $iv);
}
    return $data;
    
    }

function decrypt($data,$key){
    $iv = substr($key,0,16);
    $cipher="aes-256-cbc";

    if(strlen($iv) >0){   
        $data=openssl_decrypt($data, $cipher, $key, 0, $iv); 
        $final = json_decode($data,true);
    }
        return $final;
        


} 






?>